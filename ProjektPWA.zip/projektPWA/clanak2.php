<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "arhiva";


$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$id = 2;
$kategorija= "sport";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
}
if (isset($_GET['kategorija'])) {
    $kategorija = $_GET['kategorija'];
}

$query = "SELECT * FROM vijesti WHERE id = $id AND kategorija = '$kategorija'";
$result = mysqli_query($conn, $query);



while($row = mysqli_fetch_array($result)) { 
     

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>ČLANAK</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&family=Roboto:wght@300&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="linija"></div>
        <div class="traka"><img class="bz" src="Slike/B.Z.png" alt="Ikona"></div>
        <nav>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="vijesti1.php">BERLIN-SPORT</a></li>
                <li><a href="vijesti2.php">KULTUR UND SHOW</a></li>
                <li><a href="unos.html">UNOS VIJESTI</a></li>
                <li><a href="login.php">ADMINISTRACIJA</a></li>
                <li><a href="registracija.php">REGISTRACIJA</a></li>
            </ul>
        </nav>
    </header>
    <section>
        <div class="text_clanka">
            <div id="text"><h1><?php echo $row["naslov"]; ?></h1></div>
            <img src="Slike/<?php echo$row["slika"];?>">
            <div id="text">
            <p class="bitno"><?php echo$row["sazetak"]; ?></p>
            <p><?php echo$row["sadrzaj"]; ?></p>
            </div>
        </div>
    </section>
    <footer>
        <div class="box">
            <div class="sadrzaj">
                <p>Weitere Online-Angebote der Axel Springer SE:</p>
                <p>Matej Josipović</p>
                <p>mjosipov1@tvz.hr</p>
                <p>2023</p>
            </div>
        </div>
    </footer>
</body>
</html>
<?php } ?>