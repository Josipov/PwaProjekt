<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'arhiva';

    $conn = mysqli_connect($servername, $username, $password, $database);

    if (!$conn) {
        die('Connection failed: ' . mysqli_connect_error());
    }

    $korisnicko_ime = $_POST['ime'];
    $lozinka = $_POST['lozinka'];

    $query = "SELECT * FROM korisnik WHERE ime = ? AND lozinka = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ss", $korisnicko_ime, $lozinka);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);


    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['korisnik'] = $row['ime'];
    
        if ($row['admin'] === 'on') {
            header('Location: administracija.php');
            exit;
        } else {
            $ime = $row['ime'];
            $error_message = 'Korisnik: '. $ime. ' nema administracijska prava.';
        }
    } else {
        $error_message = 'Pogrešno korisničko ime ili lozinka.';
    }
    

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Clanak</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&family=Roboto:wght@300&display=swap" rel="stylesheet">
    </head>
    <body>
    <header>
        <div class="linija"></div>
        <div class="traka"><img class="bz" src="Slike/B.Z.png" alt="Ikona"></div>
        <nav>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="vijesti1.php">BERLIN-SPORT</a></li>
                <li><a href="vijesti2.php">KULTUR UND SHOW</a></li>
                <li><a href="unos.html">UNOS VIJESTI</a></li>
                <li><a href="login.php">ADMINISTRACIJA</a></li>
                <li><a href="registracija.php">REGISTRACIJA</a></li>
            </ul>
        </nav>
    </header>
    <section>
    <div class="odjel1">
    <form method="POST">
        <h1>Prijava</h1><br>
        <label for="ime">Korisničko ime:</label>
        <input type="text" name="ime" id="ime" required>

        <label for="lozinka">Lozinka:</label>
        <input type="password" name="lozinka" id="lozinka" required>

        <button type="submit">Prijavi se</button>
        <?php if (isset($error_message)) : ?>
        <p><?php echo $error_message; ?></p>
        <p>Ako niste registrirani, molimo vas da se <a href="registracija.php">registrirate</a>.</p>
        <?php endif; ?>
    </form>
    </div>
    </section>
    <footer>
        <div class="box">
            <div class="sadrzaj">
                <p>Weitere Online-Angebote der Axel Springer SE:</p>
                <p>Matej Josipović</p>
                <p>mjosipov1@tvz.hr</p>
                <p>2023</p>
            </div>
        </div>
    </footer>
</body>
</html>
