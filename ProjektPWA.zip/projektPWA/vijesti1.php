<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "arhiva";


$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 
     
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>SPORT</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&family=Roboto:wght@300&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="linija"></div>
        <div class="traka"><img class="bz" src="Slike/B.Z.png" alt="Ikona"></div>
        <nav>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="vijesti1.php">BERLIN-SPORT</a></li>
                <li><a href="vijesti2.php">KULTUR UND SHOW</a></li>
                <li><a href="unos.html">UNOS VIJESTI</a></li>
                <li><a href="login.php">ADMINISTRACIJA</a></li>
                <li><a href="registracija.php">REGISTRACIJA</a></li>
            </ul>
        </nav>
    </header>

    <section>
    <div class="odjel1">
        <div class="clanci">
          
          <?php
          $query = "SELECT * FROM vijesti WHERE kategorija='sport' AND ovisnost='off'";
          $result = mysqli_query($conn, $query); 
          while($row = mysqli_fetch_array($result)) {
          ?>
          <article>
            <a href="clanak2.php?id=<?php echo$row["id"]; ?>&kategorija=<?php echo$row["kategorija"]; ?>"><img src="Slike/<?php echo$row["slika"];?>" alt="Article 1"></a>
            <p><?php echo $row["podnaslov"]; ?></p>
            <a href="clanak2.php?id=<?php echo$row["id"]; ?>&kategorija=<?php echo$row["kategorija"]; ?>"><h2><?php echo $row["naslov"]; ?></h2></a>
            </article>
          <?php }?>
          
        </div>
    </div>
    </section>
    <footer>
        <div class="box">
            <div class="sadrzaj">
                <p>Weitere Online-Angebote der Axel Springer SE:</p>
                <p>Matej Josipović</p>
                <p>mjosipov1@tvz.hr</p>
                <p>2023</p>
            </div>
        </div>
    </footer>
</body>
</html>
