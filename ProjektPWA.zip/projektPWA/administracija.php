<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>ADMINISTRACIJA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&family=Roboto:wght@300&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="linija"></div>
        <div class="traka"><img class="bz" src="Slike/B.Z.png" alt="Ikona"></div>
        <nav>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="vijesti1.php">BERLIN-SPORT</a></li>
                <li><a href="vijesti2.php">KULTUR UND SHOW</a></li>
                <li><a href="unos.html">UNOS VIJESTI</a></li>
                <li><a href="login.php">ADMINISTRACIJA</a></li>
                <li><a href="registracija.php">REGISTRACIJA</a></li>
            </ul>
        </nav>
    </header>
    <section>
    <div class="odjel1">
        
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "arhiva";
    
    
    $conn = mysqli_connect($servername, $username, $password, $database);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $id = $_POST["id"];
        $updatedText = $_POST["updated_text"];
        $updatedNaslov= $_POST["updated_naslov"];
        $updatedPODNaslov= $_POST["updated_podnaslov"];
        $updatedOvisnost= $_POST["updated_ovisnost"];
        $updatedSazetak=$_POST["updated_sazetak"];
        // Izvršavanje SQL upita za ažuriranje
        $sql = "UPDATE vijesti SET sadrzaj = '$updatedText', naslov='$updatedNaslov',podnaslov='$updatedPODNaslov',ovisnost='$updatedOvisnost',sazetak='$updatedSazetak' WHERE id = $id";
    
        if (mysqli_query($conn, $sql)) {
            echo "Tekst uspješno ažuriran.";
        } else {
            echo "Pogreška prilikom ažuriranja teksta: " . mysqli_error($conn);
        }
    }
    if (isset($_POST["delete"])) {
        $id = $_POST["id"];

        $sql = "DELETE FROM vijesti WHERE id = $id";

        if (mysqli_query($conn, $sql)) {
            echo "Vijest uspješno obrisana.";
        } else {
            echo "Pogreška prilikom brisanja vijesti: " . mysqli_error($conn);
        }
    }
    
    $sql = "SELECT * FROM vijesti";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row["id"];
            $naslov = $row["naslov"];
            $podnaslov = $row["podnaslov"];
            $sadrzaj = $row["sadrzaj"];
            $ovisnost=$row["ovisnost"];
            $sazetak = $row["sazetak"];

    
            echo "<div class='odjel1-a'>";
            echo "<h1>Naslov: $naslov</h1>";
            echo "<p>Podnaslova: $podnaslov</p>";
            echo "<h3>Trenutačni sažetak:</h3>";
            echo "<h3>$sazetak</h3>";
            echo "<h3>Trenutačni sadržaj:</h3>";
            echo "<h3>$sadrzaj</h3>";
            echo "<h3>Ovisnost: $ovisnost</h3>";
            echo "<form method='post'>";
            echo "<label>Promjenite naslov:</label>";
            echo "<input type='hidden' name='id' value='$id'>";
            echo "<textarea name='updated_naslov'></textarea>";
            echo "<label>Promjenite podnaslov:</label>";
            echo "<input type='hidden' name='id' value='$id'>";
            echo "<textarea name='updated_podnaslov'></textarea>";
            echo "<label>Promjenite sažetak:</label>";
            echo "<input type='hidden' name='id' value='$id'>";
            echo "<textarea name='updated_sazetak'></textarea>";
            echo "<label>Promjenite sadržaj:</label>";
            echo "<input type='hidden' name='id' value='$id'>";
            echo "<textarea name='updated_text'></textarea>";
            echo "<label>Promjenite ovisnost:</label>";
            echo "<input type='hidden' name='id' value='$id'>";
            echo "<textarea name='updated_ovisnost'></textarea>";
            echo "<button type='submit'>Ažuriraj tekst</button>";
            echo "<button type='submit' name='delete'>Obriši vijest</button>";
            echo "</form>";
            echo "</div>";
        }
    } else {
        echo "Nema zapisa u bazi.";
    }
    
    mysqli_close($conn);
    ?>
    

    </section>
    
    <footer>
        <div class="box">
            <div class="sadrzaj">
                <p>Weitere Online-Angebote der Axel Springer SE:</p>
                <p>Matej Josipović</p>
                <p>mjosipov1@tvz.hr</p>
                <p>2023</p>
            </div>
        </div>
    </footer>
</body>
</html>