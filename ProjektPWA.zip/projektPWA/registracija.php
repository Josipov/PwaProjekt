<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "arhiva";

    $conn = mysqli_connect($servername, $username, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $ime = $_POST["ime"];
    $lozinka = $_POST["lozinka"];
    $tlozinka = $_POST["tlozinka"];
    $mogucnost = isset($_POST["mogucnost"]) ? $_POST["mogucnost"] : "off";


    if ($lozinka !== $tlozinka) {
        $error_message = "Lozinke se ne podudaraju.";
    } else {
        $query = "SELECT * FROM korisnik WHERE ime = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "s", $ime);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $error_message = "Korisničko ime već postoji. Odaberite drugo korisničko ime.";
        } else {
            $query = "INSERT INTO korisnik (ime, lozinka, admin) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "sss", $ime, $lozinka,$mogucnost);
            
            if (mysqli_stmt_execute($stmt)) {
                header("Location: login.php");
                exit();
            } else {
                $error_message = "Greška prilikom registracije korisnika: " . mysqli_error($conn);
            }
        }
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registracija</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200&family=Roboto:wght@300&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="linija"></div>
        <div class="traka"><img class="bz" src="Slike/B.Z.png" alt="Ikona"></div>
        <nav>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="vijesti1.php">BERLIN-SPORT</a></li>
                <li><a href="vijesti2.php">KULTUR UND SHOW</a></li>
                <li><a href="unos.html">UNOS VIJESTI</a></li>
                <li><a href="login.php">ADMINISTRACIJA</a></li>
                <li><a href="registracija.php">REGISTRACIJA</a></li>
            </ul>
        </nav>
    </header>
    <section>
        <div class="odjel1">
        
        
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <h1>Registracija</h1><br>
            <div>
                <label for="ime">Korisničko ime:</label>
                <input type="text" id="ime" name="ime" required>
            </div>
            <div>
                <label for="lozinka">Lozinka:</label>
                <input type="password" id="lozinka" name="lozinka" required>
            </div>
            <div>
                <label for="tlozinka">Potvrdi lozinku:</label>
                <input type="password" id="tlozinka" name="tlozinka" required>
            </div>
            <div>
            <br>
                <label for="mogućnost">Admin:<input type="checkbox" id="mogucnost" name="mogucnost"></label>
                
            </div>
            <button type="submit">Registriraj se</button>
            <?php if (isset($error_message)) : ?>
            <p><?php echo $error_message; ?></p>
            <?php endif; ?>
        </form>
        </div>
    </section>
    <footer>
        <div class="box">
            <div class="sadrzaj">
                <p>Weitere Online-Angebote der Axel Springer SE:</p>
                <p>Matej Josipović</p>
                <p>mjosipov1@tvz.hr</p>
                <p>2023</p>
            </div>
        </div>
    </footer>
</body>
</html>
