-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2023 at 03:19 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arhiva`
--
CREATE DATABASE IF NOT EXISTS `arhiva` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `arhiva`;

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(20) NOT NULL,
  `ime` varchar(32) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `admin` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `lozinka`, `admin`) VALUES
(1, 'matej', 'josip', 'on'),
(2, 'josip', 'matej', 'off'),
(4, 'marko', 'marko', 'off'),
(5, 'jakov', 'dada', 'off'),
(6, 'Luka', 'ja', 'off'),
(7, 'Marijan', 'kori', 'off'),
(8, 'Ana', 'jaja', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `naslov` varchar(500) NOT NULL,
  `podnaslov` varchar(100) NOT NULL,
  `sazetak` varchar(500) NOT NULL,
  `sadrzaj` varchar(10000) NOT NULL,
  `kategorija` varchar(32) NOT NULL,
  `slika` varchar(100) NOT NULL,
  `ovisnost` varchar(29) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `naslov`, `podnaslov`, `sazetak`, `sadrzaj`, `kategorija`, `slika`, `ovisnost`) VALUES
(1, 'Klinsmann Junior (22) verlässt Hertha – aber wohin geht er?', 'Abschied aus Berlin', 'Der Sohn von Jürgen Klinsmann (53) und amerikanische U23-Torwart verlässt Hertha zum Saisonende. Aber wohin führt sein Weg?', 'Jonathan Klinsmann (22) nimmt Abschied von Berlin! Bei seinem letzten Saisonspiel in der Regionalliga (0:2 gegen Lok. Leipzig) saß ein Beobachter der Glasgow Rangers auf der Tribüne. Es gibt auch Anfragen aus der Schweiz und Österreich.', 'sport', 'golman.jpg', 'off'),
(2, 'Paderborn-Coach Baumgart verrät Startelf für Dresden-Spiel', 'Vorm Saisonfinale', 'Das Überraschungs-Team aus Paderborn will sich den Bundesliga-Aufstieg nicht mehr nehmen lassen. Steffen Baumgart, Trainer des Tabellenzweiten, geht selbstbewusst in das Spiel in Dresden.', 'Seine Ostwestfalen gehen das Saison-Finale bei Dynamo Dresden am Sonntag (15.30 Uhr/Sky) betont optimistisch an. Wir wollen diesen zweiten Platz verteidigen\", sagte Trainer Steffen Baumgart am Freitag und verriet zur Überraschung aller sogar seine Formation. Wir werden mit derselben Startelf beginnen wie gegen Hamburg\", kündigte Baumgart an.\r\nGegen den Bundesliga-Absteiger hatten die Ostwestfalen am Sonntag im erstmals praktizierten 4-2-3-1-System mit 4:1\r\ngewonnen.\r\nZum Spiel in Dresden wird Paderborn zum erst zweiten Mal in dieser Saison fliegen. Zunachst war eine Anreise mit dem Bus oder Zug geplant, doch angesichts einer möglichen Relegation dachte Baumgart um.\r\nEs kann nachste Woche ja weitergehen\", sagte Baumgart: Deshalb fliegen wir am Sonntag um 20 Uhr zurück. Dann können wir am Montag um 10 Uhr trainieren.\"\r\nDer Tabellendritte spielt in der Relegation am 23. und 27. Mai gegen den VfB Stuttgart als 16 der Bundesliga Union Berlin liegt vor dem letzten Zweitliga-Spieltag nur einen Punkt hinter Paderborn.', 'sport', 'trener.jpg', 'off'),
(3, 'Alba-Coach: Deutsche dürfen Platz nicht wegen Passes bekommen', 'Vor Playoffs gegen Ulm', '', '', 'sport', 'skos trener.jpg', 'off'),
(4, 'In Sachen Mode hat bei Sandra Maischberger ihr Mann die Hosen an!', 'Sie hasst es, shoppen zu gehen', '', '', 'kultura', 'parstari.jpg', 'off'),
(6, ',,Meine Töchter sollen wie ich unabhängig durchs Leben gehen!\"', 'TV-Star Mariella Ahrens', '', '', 'kultura', 'zena.jpg', 'off'),
(7, ' „WM mit Nigeria ist mein großer Traum!“', 'Ex-Herthaner jetzt Nationalspieler', 'Herr Torunarigha, was sagen Sie zum Absturz Ihres Ex-Klubs Hertha?', 'Ich bin ein Berliner durch und durch. Als mein Ex-Klub abgestiegen ist, saß ich in Belgien vor dem Fernseher und war nach dem 1:1 gegen Bochum geschockt. Das hätte ich niemals erwartet, auch wenn es sich schon in den letzten Jahre angedeutet hat. Aber dass das nun passiert, ist leider sehr traurig. Ich hoffe, dass Hertha so schnell wie möglich wieder aufsteigt.', 'sport', 'nogometaš.jpg', 'off'),
(12, 'Berliner Schönheiten im Untergrund', 'Die 30 schönsten U-Bahnhöfe', 'Wer über „coole“ Orte in Berlin spricht, der könnte auch die U-Bahnhöfe meinen. ', 'Leider sind die U-Bahn-Abteile dann oft umso heißer, da sie nicht klimatisiert werden. Und natürlich sind nicht alle U-Bahnhöfe echt Schönheiten, manche sind sogar wahre Dreckecken.Doch bleiben wir ausnahmsweise bei den Schönheiten …Dabei sind wahre U-Bahn-Kathedralen wie der Heidelberger Platz, Kuriositäten wie Dahlem-Dorf, Pop-Art-Ikonen wie der Fehrbelliner Platz und ganz moderne Stationen wie Unter den Linden.', 'kultura', 'plaza.jpg', 'off');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ime` (`ime`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
